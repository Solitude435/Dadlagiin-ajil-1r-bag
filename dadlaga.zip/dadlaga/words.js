const words = [
    {
        word : "group",
        hint : "A number of objects or person"
    },
    {
        word : "taste",
        hint : "Ability of tongue to detect flavour"
    },
    {
        word : "store",
        hint : "Large shop where goods are traded"
    },
    {
        word : "field",
        hint : "Area of land for farming activities"
    },
    {
        word : "friend",
        hint : "Person oter than a family member"
    },
    {
        word : "needle",
        hint : "A thin and sharp metal pin"
    },
    {
        word : "expert",
        hint : "person with extensive knowledge"
    },
    {
        word : "tongue",
        hint : "The muscular organ of mouth"
    },
]